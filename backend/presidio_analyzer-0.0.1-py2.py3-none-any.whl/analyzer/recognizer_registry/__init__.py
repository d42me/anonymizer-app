# pylint: disable=unused-import
from analyzer.recognizer_registry.recognizers_store_api import (  # noqa: F401
    RecognizerStoreApi
)
